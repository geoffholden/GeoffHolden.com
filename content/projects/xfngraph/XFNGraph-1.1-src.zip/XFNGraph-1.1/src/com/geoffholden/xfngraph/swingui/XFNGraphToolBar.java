/*
 * Copyright 2005 Geoff Holden (gholden@ieee.org)
 *  
 * This file is part of XFN Graph.
 * 
 * XFN Graph is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * XFN Graph is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with XFN Graph; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.geoffholden.xfngraph.swingui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JToolBar;

public class XFNGraphToolBar extends JToolBar {
	private XFNGraphFrame frame;
	private JTextField url;
	private JComboBox depth;
	
	public XFNGraphToolBar(XFNGraphFrame frame) {
		this.frame = frame;
		
		url = new JTextField("http://www.geoffholden.com/");
		depth = new JComboBox(new Integer[] { new Integer(1), new Integer(2), new Integer(3), new Integer(4) });
		this.add(url);
		this.add(new JLabel("Depth:"));
		this.add(depth);
		
		JButton goButton = new JButton("Go!");
		goButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				executeGo();
			}
		});
		this.add(goButton);
		
		this.add(new JSeparator());
		
		JButton zoomIn = new JButton("+");
		zoomIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				zoomIn();
			}
		});
		this.add(zoomIn);
		
		JButton zoomOut = new JButton("-");
		zoomOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				zoomOut();
			}
		});
		this.add(zoomOut);
	}
	
	private void zoomIn() {
		frame.zoomIn();
	}
	
	private void zoomOut() {
		frame.zoomOut();
	}
	
	private void executeGo() {
		frame.spiderSite(url.getText(), ((Number) depth.getSelectedItem()).intValue()); 
	}
}
