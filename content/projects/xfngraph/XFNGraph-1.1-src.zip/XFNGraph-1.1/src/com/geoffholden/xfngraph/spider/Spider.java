/*
 * Copyright 2005 Geoff Holden (gholden@ieee.org)
 * Copyright 2005 Nicholas Shanks (contact@nickshanks.com)
 *  
 * This file is part of XFN Graph.
 * 
 * XFN Graph is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * XFN Graph is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with XFN Graph; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.geoffholden.xfngraph.spider;

import java.util.Collection;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.ListIterator;

import org.htmlparser.Parser;
import org.htmlparser.filters.NodeClassFilter;
import org.htmlparser.filters.OrFilter;
import org.htmlparser.http.ConnectionManager;
import org.htmlparser.tags.LinkTag;
import org.htmlparser.tags.TitleTag;
import org.htmlparser.util.NodeList;
import org.htmlparser.util.ParserException;

public class Spider {
	private Set sites = new HashSet();
	private Set links = new HashSet();
	private Set xfnValid;
	
	public Spider() {
		initializeValid();
		Hashtable parserProperties = ConnectionManager.getDefaultRequestProperties();
		parserProperties.put("User-Agent", "XFNGraph/1.1");
		ConnectionManager.setDefaultRequestProperties(parserProperties);
	}
	
	public void spider(Site site, int depth, SpiderProgressListener progress) {
		if (!sites.contains(site)) sites.add(site);
		for (ListIterator it = site.urls.listIterator(); it.hasNext();) {
			String url = (String) it.next();
			progress.setProgressText("Spidering " + url + "...");
			try {
				Parser parser = new Parser (url);
				NodeList list = parser.extractAllNodesThatMatch(new OrFilter(new NodeClassFilter(LinkTag.class), new NodeClassFilter(TitleTag.class)));
				for (int i = 0; i < list.size(); i++) {
					if (list.elementAt(i) instanceof TitleTag) {
						String pageTitle = ((TitleTag) list.elementAt(i)).getTitle();
						if (pageTitle != null && !pageTitle.equals("") && site.names.size() == 0) {
							site.names.add(pageTitle.trim());
						}
					} else {
						LinkTag tag = (LinkTag) list.elementAt(i);
						String rel = tag.getAttribute("rel");
						if (rel != null) {
							String[] attrs = rel.split(" ");
							for (int j = 0; j < attrs.length; j++) {
								attrs[j] = attrs[j].replaceAll(",$", "");
							}
							
							if (attrs.length == 1 && attrs[0].equals("me")) {
								// add url to this site, spider (via current list iteration) but do not decrement depth
								Site newSite = new Site();
								newSite.urls.add(tag.getLink().trim());
								if (!newSite.equals(site)) {
									for (Iterator it2 = sites.iterator(); it2.hasNext();) {
										// check for existing sites, in case we are linking to this URL already
										Site foundSite = (Site) it2.next();
										if(newSite.equals(foundSite)) {
											// change links to duplicate and remove it fromsite list
											for (Iterator it3 = links.iterator(); it3.hasNext();) {
												// set link to point to main Site object
												Link link = (Link) it3.next();
												if(link.src.equals(newSite)) link.src = site;
												if(link.dest.equals(newSite)) link.dest = site;
											}
											it2.remove();
										}
									}
									
									// add the url to this site
									it.add(tag.getLink().trim());
								}
							} else {
								Link link = new Link();
								for (int j = 0; j < attrs.length; j++) {
									if (xfnValid.contains(attrs[j]) && !attrs[j].equals("me")) {
										link.type.add(attrs[j]);
									}
								}
								
								if (link.type.size() > 0) {
									link.src = site;
									link.dest = new Site();
									link.dest.urls.add(tag.getLink().trim());
									for (Iterator it2 = sites.iterator(); it2.hasNext();) {
										// swap link.dest for existing Site if we have one which matches the URL
										Site scanSite = (Site) it2.next();
										if(link.dest.equals(scanSite)) {
											link.dest = scanSite;
										}
									}
									link.dest.names.add(tag.getLinkText().trim());
									String linkTitle = tag.getAttribute("title");
									if(linkTitle != null && !linkTitle.equals("")) {
										link.dest.names.add(linkTitle.trim());
									}
								
									links.add(link);
									if (!sites.contains(link.dest)) {
										sites.add(link.dest);
										if (depth > 1)
											spider(link.dest, depth -1, progress);
									}
								}
							}
						}
					}
				}
			}
			catch (ParserException e) {
				e.printStackTrace();
			}
		}
	}
	
	private void initializeValid() {
		xfnValid = new HashSet();
		xfnValid.add("contact");
		xfnValid.add("acquaintance");
		xfnValid.add("friend");
		xfnValid.add("met");
		xfnValid.add("coworker"); /* alt spelling */
		xfnValid.add("co-worker");
		xfnValid.add("colleague");
		xfnValid.add("coresident"); /* alt spelling */
		xfnValid.add("co-resident");
		xfnValid.add("neighbour"); /* british spelling */
		xfnValid.add("neighbor");
		xfnValid.add("child");
		xfnValid.add("parent");
		xfnValid.add("sibling");
		xfnValid.add("spouse");
		xfnValid.add("kin");
		xfnValid.add("muse");
		xfnValid.add("crush");
		xfnValid.add("date");
		xfnValid.add("dating"); /* something I found on tantek's blog */
		xfnValid.add("sweetheart");
		xfnValid.add("me");
	}
	
	public Collection getSites() {
		return sites;
	}
	public Collection getLinks() {
		return links;
	}
}
