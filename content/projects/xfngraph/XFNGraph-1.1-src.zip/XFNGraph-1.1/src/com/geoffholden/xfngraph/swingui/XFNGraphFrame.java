/*
 * Copyright 2005 Geoff Holden (gholden@ieee.org)
 * Copyright 2005 Nicholas Shanks (contact@nickshanks.com)
 *  
 * This file is part of XFN Graph.
 * 
 * XFN Graph is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * XFN Graph is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with XFN Graph; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.geoffholden.xfngraph.swingui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.filechooser.FileFilter;

import org.jgraph.JGraph;
import org.jgraph.graph.ConnectionSet;
import org.jgraph.graph.DefaultEdge;
import org.jgraph.graph.DefaultGraphCell;
import org.jgraph.graph.DefaultGraphModel;
import org.jgraph.graph.DefaultPort;
import org.jgraph.graph.GraphConstants;
import org.jgraph.layout.JGraphLayoutAlgorithm;
import org.jgraph.layout.SpringEmbeddedLayoutAlgorithm;
import org.jgraph.util.JGraphUtilities;

import com.geoffholden.xfngraph.spider.Link;
import com.geoffholden.xfngraph.spider.Site;
import com.geoffholden.xfngraph.spider.Spider;

public class XFNGraphFrame extends JFrame implements Runnable {
	private JScrollPane graphPane = new JScrollPane();
	private JGraph graph = new JGraph(new DefaultGraphModel());
	private int depth;
	private String url;
	private XFNGraphProgressDialog progress;
	
	public XFNGraphFrame() {
		this.setTitle("XFN Graph");
		this.setJMenuBar(new XFNGraphMenuBar(this));
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(new XFNGraphToolBar(this), BorderLayout.NORTH);
		this.getContentPane().add(graphPane, BorderLayout.CENTER);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(800, 600);
	}
	
	public void spiderSite(String url, int depth) {
		this.url = url;
		this.depth = depth;
		progress = new XFNGraphProgressDialog(this, true);
		new Thread(this).start();
		progress.setVisible(true);
		progress.validate();
		
	}
	
	public void zoomIn() {
		graph.setScale(graph.getScale() * 1.5);
	}
	
	public void zoomOut() {
		graph.setScale(graph.getScale() / 1.5);
	}
	
	public void run() {
		this.getContentPane().remove(this.graphPane);
		graph = new JGraph(new DefaultGraphModel());
		this.graphPane = new JScrollPane(graph);
		this.getContentPane().add(graphPane, BorderLayout.CENTER);
		ConnectionSet cs = new ConnectionSet();
		
		Spider spider = new Spider();
		Site startingSite = new Site();
		startingSite.urls.add(url);
		
		spider.spider(startingSite, depth, progress);
		
		int current = 1;
		progress.setProgressText("Creating site boxes...");
		Map cells = new HashMap();
		for (Iterator it = spider.getSites().iterator(); it.hasNext();)
		{
			Site site = (Site) it.next();
			progress.setProgressText("Creating site boxes... ("+current+")");
			DefaultGraphCell cell = new DefaultGraphCell("<html><nobr>"+site.toString()+"</nobr></html>");
			GraphConstants.setBounds(cell.getAttributes(), new Rectangle2D.Double(100,100,100,25));
			if (site.hashCode() == startingSite.hashCode())
				GraphConstants.setGradientColor(cell.getAttributes(), Color.RED);
			else GraphConstants.setGradientColor(cell.getAttributes(), Color.ORANGE);
			GraphConstants.setOpaque(cell.getAttributes(), true);
			GraphConstants.setBorder(cell.getAttributes(), BorderFactory.createRaisedBevelBorder());
			DefaultPort port = new DefaultPort();
			cell.add(port);
			port.setParent(cell);
			cells.put(site, cell);
			current += 1;
		}
		
		current = 1;
		progress.setProgressText("Creating links...");
		Collection edges = new ArrayList();
		Font edgeFont = new Font("Arial", Font.PLAIN, 10);
		for (Iterator it = spider.getLinks().iterator(); it.hasNext();)
		{
			Link link = (Link) it.next();
			if(link.src == null || link.dest == null) continue;
			progress.setProgressText("Creating links... ("+current+")");
			try {
				DefaultEdge edge = new DefaultEdge(link.getType());
				edge.setSource(((DefaultGraphCell) cells.get(link.src)).getChildAt(0));
				edge.setTarget(((DefaultGraphCell) cells.get(link.dest)).getChildAt(0));
				edges.add(edge);
				cs.connect(edge, ((DefaultGraphCell) cells.get(link.src)).getChildAt(0), ((DefaultGraphCell) cells.get(link.dest)).getChildAt(0));
				
				int arrow = GraphConstants.ARROW_CLASSIC;
				GraphConstants.setLineEnd(edge.getAttributes(), arrow);
				GraphConstants.setEndFill(edge.getAttributes(), true);
				GraphConstants.setFont(edge.getAttributes(), edgeFont);
				GraphConstants.setForeground(edge.getAttributes(), Color.BLUE);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			current += 1;
		}
		
		progress.setProgressText("Laying out graph...");
		Collection allCells = new ArrayList();
		allCells.addAll(cells.values());
		allCells.addAll(edges);
		
		graph.getGraphLayoutCache().setSelectsAllInsertedCells(false);
		graph.getGraphLayoutCache().insert(allCells.toArray(), null, cs, null, null);
		
		Rectangle size = new Rectangle(Math.max(800, cells.values().size() * 7), Math.max(600, cells.values().size() * 7));
		
		JGraphLayoutAlgorithm layout = new SpringEmbeddedLayoutAlgorithm();
		((SpringEmbeddedLayoutAlgorithm) layout).setFrame(size);
//		JGraphLayoutAlgorithm layout = new RadialTreeLayoutAlgorithm();
//		JGraphLayoutSettings settings = layout.createSettings();
//		JDialog dialog = JGraphLayoutAlgorithm.createDialog(settings,
//				this,
//				"Configure",
//				"Close",
//				"Apply");
//		if (null != dialog)
//		{
//			dialog.setVisible(true);
//		}
//		
		JGraphLayoutAlgorithm.applyLayout(graph, layout, allCells.toArray());
		progress.setVisible(false);
		progress.dispose();
		this.validate();
	}

	public void saveAsPNG() {
		JFileChooser file = new JFileChooser();
		file.setFileFilter(new FileFilter() {
			public boolean accept(File file)	{
				return file.getName().endsWith(".png") || file.getName().endsWith(".PNG");
			}
			public String getDescription() {
				return "PNG Images";
			}
		});
		
		file.showSaveDialog(this);
		BufferedImage img = JGraphUtilities.toImage(graph, JGraphUtilities.ALIGN_TOP | JGraphUtilities.ALIGN_LEFT);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		try
		{
			ImageIO.write(img, "png", bos);
			bos.flush();
			
			FileOutputStream fos = new FileOutputStream(file.getSelectedFile());
			fos.write(bos.toByteArray());
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
