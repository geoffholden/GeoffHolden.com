/*
 * Copyright 2005 Geoff Holden (gholden@ieee.org)
 * Copyright 2005 Nicholas Shanks (contact@nickshanks.com)
 *  
 * This file is part of XFN Graph.
 * 
 * XFN Graph is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * XFN Graph is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with XFN Graph; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.geoffholden.xfngraph.spider;

import java.lang.Integer;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;

public class Site
{
	public List names = new ArrayList();
	public List urls = new ArrayList();
	
	public String toString()
	{
		Map tally = new HashMap();
		for (Iterator it = names.iterator(); it.hasNext();) {
			String name = (String) it.next();
			if(tally.containsKey(name)) {
				tally.put(name, new Integer(((Integer)tally.get(name)).intValue() +1));
			}
			else tally.put(name, new Integer(1));
		}
		
		String savedName = null;
		int savedValue = 0;
		for (Iterator it = tally.keySet().iterator(); it.hasNext();)
		{
			String name = (String) it.next();
			int value = ((Integer)tally.get(name)).intValue();
			if(value > savedValue) { savedName = name; savedValue = value; }
//			System.out.println(value+": "+name);
		}
//		if(savedValue == 1)
//			System.out.println("using "+names.get(0));
//		else System.out.println("using "+savedName);
//		for (Iterator it = urls.iterator(); it.hasNext();)
//			System.out.println(it.next());
//		System.out.println("---");
		if(savedValue == 1) {
			return (String) names.get(0);
		} else {
			return savedName;
		}
	}
	
	public boolean equals(Object arg0) {
		if (arg0 instanceof Site) {
			Site other = (Site) arg0;
			for (Iterator it1 = urls.iterator(); it1.hasNext();) {
				String url = (String) it1.next();
				for (Iterator it2 = other.urls.iterator(); it2.hasNext();) {
					// strip off any 'www' or 'web' hostname, any index.html filename and trailing slash
					String otherurl = (String) it2.next();
					url = url.replaceFirst("^https?://(w[we][wb]\\d*\\.)?", "");
					url = url.replaceFirst("/([^/]*\\.[^/]*)?(\\?.*)?$", "");
					otherurl = otherurl.replaceFirst("^https?://(w[we][wb]\\d*\\.)?", "");
					otherurl = otherurl.replaceFirst("/([^/]*\\.[^/]*)?(\\?.*)?$", "");
//					System.out.println(url);
//					System.out.println(otherurl);
//					System.out.println("--");
					if (url.equals(otherurl)) {
						return true;
					}
				}
			}
		}
		return false;
	}
	
	public int hashCode() {
		return urls.hashCode();
	}
}

