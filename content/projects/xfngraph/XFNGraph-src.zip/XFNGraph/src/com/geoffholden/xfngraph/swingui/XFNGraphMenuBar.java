/*
 * Copyright 2005 Geoff Holden (gholden@ieee.org)
 *  
 * This file is part of XFN Graph.
 * 
 * XFN Graph is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * XFN Graph is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with XFN Graph; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.geoffholden.xfngraph.swingui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class XFNGraphMenuBar extends JMenuBar {
	private XFNGraphFrame frame;
	public XFNGraphMenuBar(XFNGraphFrame frame) {
		this.frame = frame;
		
		this.add(buildFileMenu());
		this.add(buildEditMenu());
	}
	
	private JMenu buildFileMenu() {
		JMenu menu = new JMenu("File");
		menu.setMnemonic('f');
		
		JMenuItem export = new JMenuItem("Export as...");
		export.setMnemonic('e');
		export.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.saveAsPNG();
			}
		});
		menu.add(export);
		
		JMenuItem exit = new JMenuItem("Exit");
		exit.setMnemonic('x');
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		menu.add(exit);
		
		return menu;
	}
	
	private JMenu buildEditMenu() {
		JMenu menu = new JMenu("Edit");
		menu.setMnemonic('e');
		
		JMenuItem zoomIn = new JMenuItem("Zoom In");
		zoomIn.setMnemonic('i');
		zoomIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.zoomIn();
			}
		});
		menu.add(zoomIn);
		
		JMenuItem zoomOut = new JMenuItem("Zoom Out");
		
		zoomOut.setMnemonic('o');
		zoomOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.zoomOut();
			}
		});
		menu.add(zoomOut);
		
		return menu;
	}
}
