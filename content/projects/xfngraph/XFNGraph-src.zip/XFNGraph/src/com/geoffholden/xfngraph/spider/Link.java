/*
 * Copyright 2005 Geoff Holden (gholden@ieee.org)
 *  
 * This file is part of XFN Graph.
 * 
 * XFN Graph is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * XFN Graph is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with XFN Graph; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.geoffholden.xfngraph.spider;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;


public class Link {
	public Site src;
	public Site dest;
	public Set type = new HashSet();
	
	public String toString()
	{
		String result = "src=" + src + " rel=(" + getType() + ") dest=" + dest;
		
		return result;
	}
	
	public String getType()
	{
		boolean first = true;
		
		String result = "";
		for (Iterator it = type.iterator(); it.hasNext();)
		{
			if (!first)
			{
				result += ",";
			}
			first = false;
			result += it.next().toString();
		}
		
		return result;
	}
	
	
	public boolean equals(Object arg0) {
		if (arg0 instanceof Link) {
			Link other = (Link) arg0;
			return other.src.equals(src) && other.dest.equals(dest);
		} else {
			return false;
		}
	}
	
	public int hashCode() {
		return src.hashCode() ^ dest.hashCode() ^ type.hashCode();
	}
}