/*
 * Copyright 2005 Geoff Holden (gholden@ieee.org)
 *  
 * This file is part of XFN Graph.
 * 
 * XFN Graph is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * XFN Graph is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with XFN Graph; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.geoffholden.xfngraph.swingui;

import java.awt.Frame;

import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JProgressBar;

import com.geoffholden.xfngraph.spider.SpiderProgressListener;

public class XFNGraphProgressDialog extends JDialog implements SpiderProgressListener {
	private JLabel status = new JLabel();
	
	/* (non-Javadoc)
	 * @see com.geoffholden.xfngraph.spider.SpiderProgressListener#setProgressText(java.lang.String)
	 */
	public void setProgressText(String text) {
		status.setText(text);
		this.validate();
	}
	
	public XFNGraphProgressDialog(Frame frame, boolean modal) {
		super(frame, modal);
		this.setTitle("Processing...");
		this.getContentPane().setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
		JProgressBar progressBar = new JProgressBar();
		progressBar.setIndeterminate(true);
		this.getContentPane().add(progressBar);
		this.getContentPane().add(status);
		this.setSize(400, 50);
		this.setLocation(200,275);
	}
}
