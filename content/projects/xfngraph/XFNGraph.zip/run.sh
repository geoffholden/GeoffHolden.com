#!/bin/sh
java -jar xfngraph.jar

